sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function(Controller) {
    'use strict';
    return Controller.extend("mickey.controller.BaseController",{
        reuseX : "anubhav",
        reuseY : "demo",
        reuseFly: function(){
            alert("i am a reuse function and i am flying!");
        },
        printReuse: function(){
            alert(this.reuseX + "  " + this.reuseY);
        }
    });
});