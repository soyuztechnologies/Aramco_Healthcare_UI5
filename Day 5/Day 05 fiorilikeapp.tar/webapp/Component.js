sap.ui.define([
    'sap/ui/core/UIComponent'
], function(UIComponent) {
    'use strict';
    return UIComponent.extend("emc2.sd.products.Component",{
        //linking the manifest
        metadata: {
            manifest: "json"
        },
        init: function(){
            //calling the base class constructor in our child class
            UIComponent.prototype.init.apply(this);
        },
        createContent: function(){
            return sap.m.Button({text: "working"});
        },
        destroy: function(){}


    });
});