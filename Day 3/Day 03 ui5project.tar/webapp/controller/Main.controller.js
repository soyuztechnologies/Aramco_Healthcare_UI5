sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller) {
    'use strict';
    return Controller.extend("mickey.controller.Main",{
        clickMe: function(){
            //Step 1: we get the view object for our controller
            var oView = this.getView();
            ///Step 2: Get the object of the input field from view
            var oField = oView.byId("idInp");
            ///Step 3: If there a property, there will be setter and getter
            var sVal = oField.getValue();

            alert("this is my controller code " + sVal);

            oField.setValue("Anurag");
            oField.setEnabled(false);
            oView.byId("idBtn").setIcon("sap-icon://home").setType("Success");
        },
        onInit: function(){
            alert("cnstructor called");
            //this.getView().byId("idBtn").setType("Error");
        },
        function2 : function(){

        },
        function3: function(){

        }
    });
});