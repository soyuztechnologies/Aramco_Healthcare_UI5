const express = require('express')
const app = express()
app.use(express.static('webapp'));
app.get('/', function (req, res) {
  res.send('Hello SAP Node developers');
})

app.get("/chandra", function(req,res){
    res.send([
        {
            "empId": 100,
            "empName": "Anubhav",
            "salary" : 9000,
            "currency":"EUR",
            "smoker":false
        },
        {
            "empId": 200,
            "empName": "Jamila",
            "salary" : 9800,
            "currency":"AED",
            "smoker":false
        }
    ]);
});

app.get("/rakesh", function(req,res){
    res.sendFile(__dirname + "/webapp/index.html")
});

console.log("server is started on http://localhost:4004");

app.listen(4004)